<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    //return view('welcome');
   return("bienvenido a la pagina principal");
});

   Route::get('curso' , function() {
    return("bienvenido a la pagina cursos");
   });

   Route::get('curso/{curso}' , function($curso) {
    return("bienvenido a la pagina cursos : $curso");
   });
